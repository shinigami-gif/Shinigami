package ani.dantotsu.media.manga

import android.Manifest
import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Parcelable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.math.MathUtils.clamp
import androidx.core.view.isGone
import androidx.core.view.isVisible
import androidx.core.view.updatePadding
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ConcatAdapter
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import ani.dantotsu.R
import ani.dantotsu.databinding.FragmentMediaSourceBinding
import ani.dantotsu.download.DownloadedType
import ani.dantotsu.download.DownloadsManager
import ani.dantotsu.download.DownloadsManager.Companion.compareName
import ani.dantotsu.download.manga.MangaDownloaderService
import ani.dantotsu.download.manga.MangaServiceDataSingleton
import ani.dantotsu.dp
import ani.dantotsu.isOnline
import ani.dantotsu.media.Media
import ani.dantotsu.media.MediaDetailsActivity
import ani.dantotsu.media.MediaDetailsViewModel
import ani.dantotsu.media.MediaNameAdapter
import ani.dantotsu.media.MediaType
import ani.dantotsu.media.manga.mangareader.ChapterLoaderDialog
import ani.dantotsu.navBarHeight
import ani.dantotsu.setBaseline
import ani.dantotsu.notifications.subscription.SubscriptionHelper
import ani.dantotsu.notifications.subscription.SubscriptionHelper.Companion.saveSubscription
import ani.dantotsu.others.LanguageMapper
import ani.dantotsu.parsers.DynamicMangaParser
import ani.dantotsu.parsers.HMangaSources
import ani.dantotsu.parsers.MangaParser
import ani.dantotsu.parsers.MangaSources
import ani.dantotsu.parsers.OfflineMangaParser
import ani.dantotsu.setNavigationTheme
import ani.dantotsu.settings.extensionprefs.MangaSourcePreferencesFragment
import ani.dantotsu.settings.saving.PrefManager
import ani.dantotsu.settings.saving.PrefName
import ani.dantotsu.snackString
import ani.dantotsu.toPx
import ani.dantotsu.util.StoragePermissions.Companion.accessAlertDialog
import ani.dantotsu.util.StoragePermissions.Companion.hasDirAccess
import ani.dantotsu.util.customAlertDialog
import com.google.android.material.appbar.AppBarLayout
import eu.kanade.tachiyomi.extension.manga.model.MangaExtension
import eu.kanade.tachiyomi.source.ConfigurableSource
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import uy.kohesive.injekt.Injekt
import uy.kohesive.injekt.api.get
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.roundToInt

open class MangaReadFragment : Fragment(), ScanlatorSelectionListener {
    private var _binding: FragmentMediaSourceBinding? = null
    private val binding get() = _binding!!
    private val model: MediaDetailsViewModel by activityViewModels()

    private lateinit var media: Media

    private var start = 0
    private var end: Int? = null
    private var style: Int? = null
    private var reverse = false

    private lateinit var headerAdapter: MangaReadAdapter
    private lateinit var chapterAdapter: MangaChapterAdapter

    val downloadManager = Injekt.get<DownloadsManager>()

    var screenWidth = 0f
    private var progress = View.VISIBLE

    var continueEp: Boolean = false
    var loaded = false
    private var isReceiverRegistered = false

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentMediaSourceBinding.inflate(inflater, container, false)
        return _binding?.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val intentFilter = IntentFilter().apply {
            addAction(ACTION_DOWNLOAD_STARTED)
            addAction(ACTION_DOWNLOAD_FINISHED)
            addAction(ACTION_DOWNLOAD_FAILED)
            addAction(ACTION_DOWNLOAD_PROGRESS)
        }

        if (!isReceiverRegistered) {
            ContextCompat.registerReceiver(
                requireContext(),
                downloadStatusReceiver,
                intentFilter,
                ContextCompat.RECEIVER_EXPORTED
            )
            isReceiverRegistered = true
        }

        val mediaDetailsActivity = activity as? MediaDetailsActivity
        if (mediaDetailsActivity?.bindingReady == true) {
            val actBinding = mediaDetailsActivity.binding
            val baselineAnchor = actBinding.mediaBottomBarContainer ?: actBinding.commentMessageContainer
            baselineAnchor?.let {
                val includeSystemPaddings = it != actBinding.mediaBottomBarContainer
                binding.mediaSourceRecycler.setBaseline(it, includeSystemNavBar = includeSystemPaddings)
                binding.mediaSourceRecycler.clipToPadding = false
            }
        }
        screenWidth = resources.displayMetrics.widthPixels.dp

        var maxGridSize = (screenWidth / 100f).roundToInt()
        maxGridSize = max(4, maxGridSize - (maxGridSize % 2))

        val gridLayoutManager = GridLayoutManager(requireContext(), maxGridSize)

        gridLayoutManager.spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
            override fun getSpanSize(position: Int): Int {
                val style = chapterAdapter.getItemViewType(position)

                return when (position) {
                    0 -> maxGridSize
                    else -> when (style) {
                        0 -> maxGridSize
                        1 -> 1
                        else -> maxGridSize
                    }
                }
            }
        }

        binding.mediaSourceRecycler.layoutManager = gridLayoutManager

        binding.mediaSourceSwipeRefresh.apply {
            val primaryColor = PrefManager.getVal<Int>(PrefName.PrimaryColor)
            setColorSchemeColors(primaryColor)
            setProgressBackgroundColorSchemeResource(R.color.nav_bg)
            setOnRefreshListener {
                if (!this@MangaReadFragment::media.isInitialized) {
                    isRefreshing = false
                    return@setOnRefreshListener
                }
                viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                    val ctx = context
                    val offline = (ctx != null && !isOnline(ctx)) || PrefManager.getVal(PrefName.OfflineMode)
                    if (offline && media.format != "LOCAL") {
                        media.selected!!.sourceIndex = model.mangaReadSources!!.list.lastIndex
                    }
                    model.loadMangaChapters(media, media.selected!!.sourceIndex, invalidate = true)
                    withContext(Dispatchers.Main) {
                        _binding?.mediaSourceSwipeRefresh?.isRefreshing = false
                    }
                }
            }
        }

        binding.ScrollTop.setOnClickListener {
            binding.mediaSourceRecycler.scrollToPosition(10)
            binding.mediaSourceRecycler.smoothScrollToPosition(0)
        }
        binding.mediaSourceRecycler.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                super.onScrolled(recyclerView, dx, dy)

                val position = gridLayoutManager.findFirstVisibleItemPosition()
                if (position > 2) {
                    binding.ScrollTop.translationY = -(navBarHeight + 12.toPx).toFloat()
                    binding.ScrollTop.visibility = View.VISIBLE
                } else {
                    binding.ScrollTop.visibility = View.GONE
                }
            }
        })
        model.scrolledToTop.observe(viewLifecycleOwner) {
            if (it) binding.mediaSourceRecycler.scrollToPosition(0)
        }

        continueEp = model.continueMedia ?: false
        model.getMedia().observe(viewLifecycleOwner) {
            if (it != null) {
                if (this::media.isInitialized) {
                    if (it.manga != null && it.manga?.chapters == null) {
                        it.manga?.chapters = media.manga?.chapters
                    }
                }
                media = it
                progress = View.GONE
                binding.mediaInfoProgressBar.visibility = progress

                if (media.format in setOf("MANGA", "ONE SHOT", "MANHWA", "MANHUA", "ONE_SHOT", "DOUJINSHI") || (media.format == "LOCAL" && media.manga != null)) {
                    // For LOCAL
                    if (media.format != "LOCAL" || media.selected == null) {
                        media.selected = model.loadSelected(media)
                    }

                    subscribed =
                        SubscriptionHelper.getSubscriptions().containsKey(media.id)

                    style = media.selected!!.recyclerStyle
                    reverse = media.selected!!.recyclerReversed

                    if (!loaded) {
                        model.mangaReadSources = if (media.isAdult) HMangaSources else MangaSources

                        headerAdapter = MangaReadAdapter(it, this, model.mangaReadSources!!)
                        headerAdapter.scanlatorSelectionListener = this
                        chapterAdapter =
                            MangaChapterAdapter(
                                style ?: PrefManager.getVal(PrefName.MangaDefaultView), media, this
                            )

                        for (download in downloadManager.mangaDownloadedTypes) {
                            if (media.compareName(download.titleName)) {
                                chapterAdapter.stopDownload(download.uniqueName)
                            }
                        }

                        binding.mediaSourceRecycler.adapter =
                            ConcatAdapter(headerAdapter, chapterAdapter)

                        viewLifecycleOwner.lifecycleScope.launch(Dispatchers.IO) {
                            val ctx = context
                            val offline =
                                (ctx != null && !isOnline(ctx)) || PrefManager.getVal(PrefName.OfflineMode)
                            if (offline && media.format != "LOCAL") media.selected!!.sourceIndex =
                                model.mangaReadSources!!.list.lastIndex
                            model.loadMangaChapters(media, media.selected!!.sourceIndex)
                        }
                        loaded = true
                    } else {
                        reload()
                    }
                } else {
                    binding.mediaNotSupported.visibility = View.VISIBLE
                    binding.mediaNotSupported.text =
                        getString(R.string.not_supported, media.format ?: "")
                }
            }
        }

        model.getMangaChapters().observe(viewLifecycleOwner) { _ ->
            updateChapters()
        }
    }

    override fun onScanlatorsSelected() {
        updateChapters()
    }

    fun multiDownload(n: Int) {
        lifecycleScope.launch {
            // Get the last viewed chapter
            val selected = media.userProgress ?: 0
            val chapters = media.manga?.chapters?.values?.toList()
            // Ensure chapters are available in the extensions
            if (chapters.isNullOrEmpty() || n < 1) return@launch
            // Find the index of the last viewed chapter
            val progressChapterIndex = (chapters.indexOfFirst {
                MediaNameAdapter.findChapterNumber(it.number)?.toInt() == selected
            } + 1).coerceAtLeast(0)
            // Calculate the end value for the range of chapters to download
            val endIndex = (progressChapterIndex + n).coerceAtMost(chapters.size)
            // Get the list of chapters to download
            val chaptersToDownload = chapters.subList(progressChapterIndex, endIndex)
            // Trigger the download for each chapter sequentially
            for (chapter in chaptersToDownload) {
                try {
                    downloadChapterSequentially(chapter)
                } catch (e: Exception) {
                    Toast.makeText(requireContext(), "Failed to download chapter: ${chapter.title}", Toast.LENGTH_SHORT).show()
                }
            }
            Toast.makeText(requireContext(), "All downloads completed!", Toast.LENGTH_SHORT).show()
        }
    }
    private suspend fun downloadChapterSequentially(chapter: MangaChapter) {
        withContext(Dispatchers.IO) {
            onMangaChapterDownloadClick(chapter)
            delay(2000) // A 2-second download
        }
    }


    private fun updateChapters() {
        val loadedChapters = model.getMangaChapters().value
        if (loadedChapters != null) {
            val chapters = loadedChapters[media.selected!!.sourceIndex]
            if (chapters != null) {
                headerAdapter.options = getScanlators(chapters)
                val filteredChapters =
                    if (model.mangaReadSources?.get(media.selected!!.sourceIndex) is OfflineMangaParser) {
                        chapters
                    } else {
                        chapters.filterNot { (_, chapter) ->
                            chapter.scanlator in headerAdapter.hiddenScanlators
                        }
                    }

                media.manga?.chapters = filteredChapters.toMutableMap()

                //CHIP GROUP
                val total = filteredChapters.size
                val divisions = total.toDouble() / 10
                start = 0
                end = null
                val limit = when {
                    (divisions < 25) -> 25
                    (divisions < 50) -> 50
                    else -> 100
                }
                headerAdapter.clearChips()
                if (total > limit) {
                    val arr = filteredChapters.keys.toTypedArray()
                    val stored = ceil((total).toDouble() / limit).toInt()

                    val anilistEp = (media.userProgress ?: 0).plus(1)
                    val appEp = PrefManager.getCustomVal<String?>(
                        "${media.id}_current_ep", ""
                    )?.let { MediaNameAdapter.findChapterNumber(it)?.toInt() ?: it.toIntOrNull() } ?: 1
                    val targetChpNum = (if (anilistEp > appEp) anilistEp else appEp).toFloat()

                    var targetIndex = arr.indexOfFirst { key ->
                        val chObj = filteredChapters[key]
                        val num = MediaNameAdapter.findChapterNumber(chObj?.number ?: key)
                        num != null && (num == targetChpNum || num.toInt() == targetChpNum.toInt())
                    }
                    if (targetIndex == -1) {
                        val targetIdx = targetChpNum.toInt() - 1
                        if (targetIdx in arr.indices) {
                            targetIndex = targetIdx
                        }
                    }

                    val targetChip = if (targetIndex >= 0) (targetIndex / limit).coerceIn(0, stored - 1) else 0
                    val position = if (media.selected!!.chip == 0 && targetChip > 0) {
                        media.selected!!.chip = targetChip
                        targetChip
                    } else {
                        clamp(media.selected!!.chip, 0, stored - 1)
                    }
                    val last = if (position + 1 == stored) total else (limit * (position + 1))
                    start = limit * (position)
                    end = last - 1
                    headerAdapter.updateChips(
                        limit,
                        arr,
                        (1..stored).toList().toTypedArray(),
                        position
                    )
                }

                headerAdapter.subscribeButton(true)
                reload()
            }
        }
    }

    private fun getScanlators(chap: MutableMap<String, MangaChapter>?): List<String> {
        val scanlators = mutableListOf<String>()
        if (chap != null) {
            val chapters = chap.values
            for (chapter in chapters) {
                scanlators.add(chapter.scanlator ?: "Unknown")
            }
        }
        return scanlators.distinct()
    }

    fun onSourceChange(i: Int): MangaParser {
        media.manga?.chapters = null
        reload()
        val selected = model.loadSelected(media)
        model.mangaReadSources?.get(selected.sourceIndex)?.showUserTextListener = null
        selected.sourceIndex = i
        selected.server = null
        model.saveSelected(media.id, selected)
        media.selected = selected
        return model.mangaReadSources?.get(i)!!
    }

    fun onLangChange(i: Int, saveName: String) {
        val selected = model.loadSelected(media)
        selected.langIndex = i
        model.saveSelected(media.id, selected)
        media.selected = selected
        PrefManager.removeCustomVal("${saveName}_${media.id}")
    }

    fun onScanlatorChange(list: List<String>) {
        val selected = model.loadSelected(media)
        selected.scanlators = list
        model.saveSelected(media.id, selected)
        media.selected = selected
    }

    fun loadChapters(i: Int, invalidate: Boolean) {
        lifecycleScope.launch(Dispatchers.IO) { model.loadMangaChapters(media, i, invalidate) }
    }

    fun onIconPressed(viewType: Int, rev: Boolean) {
        style = viewType
        reverse = rev
        media.selected!!.recyclerStyle = style
        media.selected!!.recyclerReversed = reverse
        model.saveSelected(media.id, media.selected!!)
        reload()
    }

    fun onChipClicked(i: Int, s: Int, e: Int) {
        media.selected!!.chip = i
        start = s
        end = e
        model.saveSelected(media.id, media.selected!!)
        reload()
    }

    var subscribed = false
    fun onNotificationPressed(subscribed: Boolean, source: String) {
        this.subscribed = subscribed
        saveSubscription(media, subscribed)
        snackString(
            if (subscribed) getString(R.string.subscribed_notification, source)
            else getString(R.string.unsubscribed_notification)
        )
    }

    fun openSettings(pkg: MangaExtension.Installed) {
        val changeUIVisibility: (Boolean) -> Unit = { show ->
            val activity = activity
            if (activity is MediaDetailsActivity && isAdded) {
                activity.findViewById<AppBarLayout>(R.id.mediaAppBar).isVisible = show
                activity.findViewById<ViewPager2>(R.id.mediaViewPager).isVisible = show
                activity.findViewById<CardView>(R.id.mediaCover).isVisible = show
                activity.findViewById<CardView>(R.id.mediaClose).isVisible = show
                activity.navBar.isVisible = show
                activity.findViewById<FrameLayout>(R.id.fragmentExtensionsContainer).isGone = show
            }
        }
        var itemSelected = false
        val allSettings = pkg.sources.filterIsInstance<ConfigurableSource>()
        if (allSettings.isNotEmpty()) {
            var selectedSetting = allSettings[0]
            if (allSettings.size > 1) {
                val names =
                    allSettings.map { LanguageMapper.getLanguageName(it.lang) }.toTypedArray()
                requireContext().customAlertDialog().apply {
                    setTitle("Select a Source")
                    singleChoiceItems(names) { which ->
                        selectedSetting = allSettings[which]
                        itemSelected = true

                        val fragment =
                            MangaSourcePreferencesFragment().getInstance(selectedSetting.id) {
                                changeUIVisibility(true)
                                loadChapters(media.selected!!.sourceIndex, true)
                            }
                        parentFragmentManager.beginTransaction()
                            .setCustomAnimations(R.anim.slide_up, R.anim.slide_down)
                            .replace(R.id.fragmentExtensionsContainer, fragment)
                            .addToBackStack(null)
                            .commit()
                    }
                    onDismiss {
                        if (!itemSelected) {
                            changeUIVisibility(true)
                        }
                    }
                    show()

                }
            } else {
                // If there's only one setting, proceed with the fragment transaction
                val fragment = MangaSourcePreferencesFragment().getInstance(selectedSetting.id) {
                    changeUIVisibility(true)
                    loadChapters(media.selected!!.sourceIndex, true)
                }
                parentFragmentManager.beginTransaction()
                    .setCustomAnimations(R.anim.slide_up, R.anim.slide_down)
                    .replace(R.id.fragmentExtensionsContainer, fragment)
                    .addToBackStack(null)
                    .commit()
            }

            changeUIVisibility(false)
        } else {
            Toast.makeText(requireContext(), "Source is not configurable", Toast.LENGTH_SHORT)
                .show()
        }
    }

    fun onMangaChapterClick(i: MangaChapter) {
        model.continueMedia = false
        media.manga?.chapters?.get(i.uniqueNumber())?.let {
            media.manga?.selectedChapter = i
            model.saveSelected(media.id, media.selected!!)
            ChapterLoaderDialog.newInstance(it, true)
                .show(requireActivity().supportFragmentManager, "dialog")
        }
    }

    fun onMangaChapterDownloadClick(i: MangaChapter) {
        activity?.let {
            if (!isNotificationPermissionGranted()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    ActivityCompat.requestPermissions(
                        it,
                        arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                        1
                    )
                }
            }
            fun continueDownload() {
                if (PrefManager.getVal<Boolean>(PrefName.DownloadWifiOnly) && !ani.dantotsu.isWifiConnected(requireContext())) {
                    snackString(getString(R.string.download_wifi_only_warning))
                    return
                }
                val uniqueNum = i.uniqueNumber()
                if (chapterAdapter.isDownloading(uniqueNum) || chapterAdapter.isDownloaded(uniqueNum)) {
                    return
                }
                chapterAdapter.startDownload(uniqueNum)
                model.continueMedia = false
                media.manga?.chapters?.get(uniqueNum)?.let { chapter ->
                    val parser =
                        model.mangaReadSources?.get(media.selected!!.sourceIndex) as? DynamicMangaParser
                    parser?.let {
                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val images = parser.imageList(chapter.sChapter)

                                // Create a download task
                                val downloadTask = MangaDownloaderService.DownloadTask(
                                    title = media.mainName(),
                                    chapter = chapter.number,
                                    scanlator = chapter.scanlator ?: "Unknown",
                                    imageData = images,
                                    sourceMedia = media,
                                    retries = 25,
                                    simultaneousDownloads = 2
                                )

                                val isAlreadyQueued = MangaServiceDataSingleton.downloadQueue.any { it.title == media.mainName() && (it.chapter == chapter.number || it.chapter == chapter.title) } ||
                                                      MangaServiceDataSingleton.currentTasks.any { it.title == media.mainName() && (it.chapter == chapter.number || it.chapter == chapter.title) }
                                if (!isAlreadyQueued) {
                                    MangaServiceDataSingleton.downloadQueue.offer(downloadTask)
                                }

                                val intent = Intent(context, MangaDownloaderService::class.java)
                                withContext(Dispatchers.Main) {
                                    ContextCompat.startForegroundService(requireContext(), intent)
                                }
                                MangaServiceDataSingleton.isServiceRunning = true
                            } catch (e: Exception) {
                                withContext(Dispatchers.Main) {
                                    chapterAdapter.purgeDownload(uniqueNum)
                                }
                            }
                        }
                    }
                }
            }
            if (!hasDirAccess(it)) {
                (it as MediaDetailsActivity).accessAlertDialog(it.launcher) { success ->
                    if (success) {
                        continueDownload()
                    } else {
                        snackString(getString(R.string.download_permission_required))
                    }
                }
            } else {
                continueDownload()
            }
        }
    }

    private fun isNotificationPermissionGranted(): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return ActivityCompat.checkSelfPermission(
                requireContext(),
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        }
        return true
    }


    fun onMangaChapterRemoveDownloadClick(i: MangaChapter) {
        downloadManager.removeDownload(
            DownloadedType(
                media.mainName(),
                i.number,
                MediaType.MANGA,
                scanlator = i.scanlator ?: "Unknown"
            )
        ) {
            chapterAdapter.deleteDownload(i)
            val isOffline = model.mangaReadSources?.get(media.selected?.sourceIndex ?: 0) is OfflineMangaParser
            if (isOffline) {
                model.invalidateMangaSource(media.selected?.sourceIndex ?: 0)
                loadChapters(media.selected?.sourceIndex ?: 0, true)
            }
        }
    }

    fun onMangaChapterStopDownloadClick(i: MangaChapter) {
        val cancelIntent = Intent().apply {
            action = MangaDownloaderService.ACTION_CANCEL_DOWNLOAD
            putExtra(MangaDownloaderService.EXTRA_CHAPTER, i.number)
        }
        requireContext().sendBroadcast(cancelIntent)

        // Remove the download from the manager and update the UI
        downloadManager.removeDownload(
            DownloadedType(
                media.mainName(),
                i.number,
                MediaType.MANGA,
                scanlator = i.scanlator ?: "Unknown"
            )
        ) {
            chapterAdapter.purgeDownload(i.uniqueNumber())
            chapterAdapter.purgeDownload(i.number)
        }
    }

    private val downloadStatusReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (!this@MangaReadFragment::chapterAdapter.isInitialized) return
            when (intent.action) {
                ACTION_DOWNLOAD_STARTED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_CHAPTER_NUMBER)
                    chapterNumber?.let { chapterAdapter.startDownload(it) }
                }

                ACTION_DOWNLOAD_FINISHED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_CHAPTER_NUMBER)
                    chapterNumber?.let { chapterAdapter.stopDownload(it) }
                }

                ACTION_DOWNLOAD_FAILED -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_CHAPTER_NUMBER)
                    chapterNumber?.let {
                        chapterAdapter.purgeDownload(it)
                    }
                }

                ACTION_DOWNLOAD_PROGRESS -> {
                    val chapterNumber = intent.getStringExtra(EXTRA_CHAPTER_NUMBER)
                    val progress = intent.getIntExtra("progress", 0)
                    val downloadedBytes = intent.getLongExtra(EXTRA_DOWNLOADED_BYTES, -1L)
                    val estimatedTotalBytes = intent.getLongExtra(EXTRA_ESTIMATED_TOTAL_BYTES, -1L)
                    chapterNumber?.let {
                        chapterAdapter.updateDownloadProgress(
                            it,
                            progress,
                            downloadedBytes,
                            estimatedTotalBytes
                        )
                    }
                }
            }
        }
    }


    @SuppressLint("NotifyDataSetChanged")
    private fun reload() {
        val selected = model.loadSelected(media)

        // Find latest chapter for subscription
        selected.latest =
            media.manga?.chapters?.values?.maxOfOrNull {
                MediaNameAdapter.findChapterNumber(it.number) ?: 0f
            } ?: 0f
        selected.latest =
            media.userProgress?.toFloat()?.takeIf { selected.latest < it } ?: selected.latest

        model.saveSelected(media.id, selected)
        headerAdapter.handleChapters()
        chapterAdapter.notifyItemRangeRemoved(0, chapterAdapter.arr.size)
        var arr: ArrayList<MangaChapter> = arrayListOf()
        if (media.manga!!.chapters != null) {
            val end = if (end != null && end!! < media.manga!!.chapters!!.size) end else null
            arr.addAll(
                media.manga!!.chapters!!.values.toList()
                    .slice(start..(end ?: (media.manga!!.chapters!!.size - 1)))
            )
            if (reverse)
                arr = (arr.reversed() as? ArrayList<MangaChapter>) ?: arr
        }
        chapterAdapter.arr = arr
        chapterAdapter.updateType(style ?: PrefManager.getVal(PrefName.MangaDefaultView))

        // Synchronize downloaded chapters for the current media
        for (download in downloadManager.mangaDownloadedTypes) {
            if (media.compareName(download.titleName)) {
                chapterAdapter.stopDownload(download.uniqueName)
                chapterAdapter.stopDownload(download.chapterName)
            }
        }

        chapterAdapter.notifyItemRangeInserted(0, arr.size)
    }

    override fun onDestroyView() {
        if (isReceiverRegistered) {
            try {
                context?.unregisterReceiver(downloadStatusReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        if (::headerAdapter.isInitialized) {
            headerAdapter.clearBinding()
        }
        super.onDestroyView()
        _binding?.mediaSourceRecycler?.adapter = null
        _binding = null
    }

    override fun onDestroy() {
        model.mangaReadSources?.flushText()
        if (isReceiverRegistered) {
            try {
                context?.unregisterReceiver(downloadStatusReceiver)
            } catch (_: Exception) {}
            isReceiverRegistered = false
        }
        super.onDestroy()
    }

    private var state: Parcelable? = null
    override fun onResume() {
        super.onResume()
        binding.mediaInfoProgressBar.visibility = progress
        binding.mediaSourceRecycler.layoutManager?.onRestoreInstanceState(state)

        requireActivity().setNavigationTheme()

        if (this::media.isInitialized && this::headerAdapter.isInitialized) {
            val isCurrentlySubscribed = SubscriptionHelper.getSubscriptions().containsKey(media.id)
            if (subscribed != isCurrentlySubscribed) {
                subscribed = isCurrentlySubscribed
                headerAdapter.subscribe?.setState(isCurrentlySubscribed)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        state = binding.mediaSourceRecycler.layoutManager?.onSaveInstanceState()
    }

    companion object {
        const val ACTION_DOWNLOAD_STARTED = "ani.dantotsu.ACTION_DOWNLOAD_STARTED"
        const val ACTION_DOWNLOAD_FINISHED = "ani.dantotsu.ACTION_DOWNLOAD_FINISHED"
        const val ACTION_DOWNLOAD_FAILED = "ani.dantotsu.ACTION_DOWNLOAD_FAILED"
        const val ACTION_DOWNLOAD_PROGRESS = "ani.dantotsu.ACTION_DOWNLOAD_PROGRESS"
        const val EXTRA_CHAPTER_NUMBER = "extra_chapter_number"
        const val EXTRA_DOWNLOADED_BYTES = "extra_downloaded_bytes"
        const val EXTRA_ESTIMATED_TOTAL_BYTES = "extra_estimated_total_bytes"
    }
}
